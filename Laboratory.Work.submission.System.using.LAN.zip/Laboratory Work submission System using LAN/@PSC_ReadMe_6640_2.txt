Title: Mac Look and Feel for Java in Windows
Description: This is simple Netbeans GUI code that creates a MAC OS LOOK and FEEL in Windows environment. This code contains a one JAR file liquidLnF.jar that must be added into Library. There is very simple line of codes in main method to change the look and feel.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6640&lngWId=2

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
